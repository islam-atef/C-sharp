using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;




public class StatusCs
{

    public enum STATUS
    {
        Success,
        Failed,
        Error
    };

    // prohibited status StatusLOG[];
}
